from flask import Flask, jsonify

application = Flask(__name__)

@application.route('/')
def home():
    return jsonify({"message": "Hello from the Backend API!"})

@application.route('/data')
def data():
    return jsonify({
        "users": ["12WKChallenge", "Roland", "Paula Wakabi"],
        "message": "Backend is running as it should, Paula"
    })

if __name__ == '__main__':
    application.run(host='0.0.0.0', port=8080)  # IMPORTANT: EB listens on port 8080
